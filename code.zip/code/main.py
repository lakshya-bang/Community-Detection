import copy
from tkinter import *
from tkinter import messagebox
from tkinter import ttk

import networkx as nx


def ui():
    root = Tk()
    frm = ttk.Frame(root, padding=10)
    frm.grid()
    ttk.Button(frm, text="URV Email Graph", command=lambda: urvEmail()).grid(column=1, row=0)
    ttk.Button(frm, text="Karate Club Graph", command=lambda: karateClub()).grid(column=2, row=0)
    ttk.Button(frm, text="Quit", command=root.destroy).grid(column=3, row=0)

    root.mainloop()


def getText(node_g, edge_g, node_cg, edge_cg, seeds, C, Q, cgfileName, cfileName):
    text = "Number of nodes before compression: " + str(node_g)
    text = text + "\nNumber of edges before compression: " + str(edge_g)
    text = text + "\n\nNumber of nodes after compression: " + str(node_cg)
    text = text + "\nNumber of edges after compression: " + str(edge_cg)

    cr = 0.5 * ((node_g - node_cg) / node_g + (edge_g - edge_cg) / edge_g)
    text = text + "\nCompression Ratio % = " + str(cr * 100)
    text = text + "\n(Compressed graph saved as " + cgfileName + " in weighted edge list format)"
    text = text + "\n\nSeeds: " + str(seeds)
    text = text + "\n(Community and nodes in the community are saved in " + cfileName + " in format:"
    text = text + "\n[seed]: \n[Space separated list of vertices])"
    text = text + "\n\nModularity(Q): " + str(Q)
    return text


def urvEmail():
    graph = nx.read_weighted_edgelist("email.edgelist")

    node_g, edge_g, node_cg, edge_cg, seeds, C, Q = detectCommunity(graph, "urvEmailCompressed.edgelist",
                                                                    "urvEmailCommunity.txt")

    text = getText(node_g, edge_g, node_cg, edge_cg, seeds, C, Q, "urvEmailCompressed.edgelist",
                   "urvEmailCommunity.txt")
    messagebox.showinfo("Results of URV Email Graph ", text)


def karateClub():
    graph = nx.karate_club_graph()
    node_g, edge_g, node_cg, edge_cg, seeds, C, Q = detectCommunity(graph, "karateCompressed.edgelist",
                                                                    "karateCommunity.edgelist")
    text = getText(node_g, edge_g, node_cg, edge_cg, seeds, C, Q, "karateCompressed.edgelist",
                   "karateCommunity.edgelist")
    messagebox.showinfo("Results of Karate Club Graph ", text)


def detectCommunity(graph, cgfileName, cfileName):
    # graph = nx.karate_club_graph()

    cgraph, iv = compressGraph(graph)
    print("IV: " + str(iv))
    nx.write_weighted_edgelist(cgraph, cgfileName)

    seeds = determineSeeds(graph, cgraph, iv)
    print("Number of nodes before compression " + str(len(graph.nodes)))
    print("Number of nodes after compression " + str(len(cgraph.nodes)))
    print("Seeds " + str(seeds))

    C = expandSeeds(cgraph, seeds)
    check_num = sum([len(C[c]) for c in seeds])

    if check_num != len(cgraph.nodes):
        print("Error ! Not all nodes have been covered")
        print("Actual : " + str(len(cgraph.nodes)) + " Covered : " + str(check_num))

    propogateLabel(seeds, C, cgraph, iv)

    with open(cfileName, "w") as file:
        for seed in seeds:
            file.write(str(seed) + ":\n")
            for vertex in C[seed]:
                file.write(str(vertex) + " ")
            file.write("\n")
    Q = modularity(graph, C, seeds)
    print("Modularity is " + str(Q))
    return [len(graph.nodes), graph.number_of_edges(), len(cgraph.nodes), cgraph.number_of_edges(), seeds, C, Q]


def findCommunity(C, seeds, super_node):
    for seed in seeds:
        if super_node in C[seed]:
            return seed

    print("Error ! " + super_node + " not present in any community")
    return -1


def addSuperNode(node, iv, community):
    if len(iv[node]) > 1:
        for vertex in iv[node]:
            if vertex != node:
                addSuperNode(vertex, iv, community)
            else:
                community.add(node)
    else:
        community.add(node)


def propogateLabel(seeds, C, cgraph, iv):
    for super_node in cgraph:
        c = findCommunity(C, seeds, super_node)
        addSuperNode(super_node, iv, C[c])


def isBridgeNode(vertex, graph):
    isDeg2 = (graph.degree[vertex] == 2)
    neighbours = list(nx.neighbors(graph, vertex))
    hasEdge = graph.has_edge(neighbours[0], neighbours[1])

    neighbours_of_n0 = set(nx.neighbors(graph, neighbours[0]))
    neighbours_of_n1 = set(nx.neighbors(graph, neighbours[1]))

    common_neighbours = len(neighbours_of_n0.intersection(neighbours_of_n1))
    return common_neighbours <= 1 and not hasEdge


def compressGraph(graph):
    # initialize compressed graph
    cgraph = copy.deepcopy(graph)

    # compute degree-1 and degree-2 vertices
    deg1 = [vertex for vertex in graph.nodes if cgraph.degree[vertex] == 1]
    deg2 = [vertex for vertex in graph.nodes if cgraph.degree[vertex] == 2]

    # initialise super node sets
    iv = {vertex: {vertex} for vertex in graph.nodes}

    while len(deg2) != 0 or len(deg1) != 0:
        for vertex in deg1:
            # remove nodes of degree 1 and add it to super node list
            neighbour = list(cgraph[vertex])[0]
            iv[neighbour].add(vertex)
            cgraph.remove_node(vertex)

            # check the degree of the neighbour and add to deg1 | deg2 accordingly
            # remove from deg1 or deg2 if present

            if cgraph.degree[neighbour] == 1:
                if neighbour in deg2:
                    deg2.remove(neighbour)
                deg1.append(neighbour)
            elif cgraph.degree[neighbour] == 2:
                deg2.append(neighbour)
            deg1.remove(vertex)

        for vertex in deg2:
            # remove nodes of degree 2 as long as it is not a bridge node
            neighbours = list(cgraph[vertex])
            # if not bridge node merge vertex into higher degree neighbour and update weight
            if not isBridgeNode(vertex, cgraph):
                if cgraph.degree[neighbours[0]] > cgraph.degree[neighbours[1]]:
                    max_deg_neighbour = neighbours[0]
                    min_deg_neighbour = neighbours[1]
                else:
                    max_deg_neighbour = neighbours[1]
                    min_deg_neighbour = neighbours[0]

                wn0 = cgraph.edges[vertex, max_deg_neighbour]['weight']
                wn1 = cgraph.edges[vertex, min_deg_neighbour]['weight']

                cgraph.remove_node(vertex)
                if not cgraph.has_edge(max_deg_neighbour, min_deg_neighbour):
                    cgraph.add_edge(max_deg_neighbour, min_deg_neighbour, weight=0)

                w01 = cgraph.edges[max_deg_neighbour, min_deg_neighbour]["weight"]
                cgraph.edges[max_deg_neighbour, min_deg_neighbour]['weight'] = w01 + 0.5 * wn1 * wn0
                print("Weight = " + str(w01 + 0.5 * wn1 * wn0))
                iv[max_deg_neighbour].add(vertex)

                # remove max_deg_neighbour and min_deg_neighbour from deg1 or deg2 if present
                if max_deg_neighbour in deg1:
                    deg1.remove(max_deg_neighbour)
                elif max_deg_neighbour in deg2:
                    deg2.remove(max_deg_neighbour)

                if min_deg_neighbour in deg1:
                    deg1.remove(min_deg_neighbour)
                elif min_deg_neighbour in deg2:
                    deg2.remove(min_deg_neighbour)

                # add vertices max_deg and min_deg to deg1 or deg2 accordingly
                if cgraph.degree[max_deg_neighbour] == 2:
                    deg2.append(max_deg_neighbour)
                elif cgraph.degree[max_deg_neighbour] == 1:
                    deg1.append(max_deg_neighbour)

                if cgraph.degree[min_deg_neighbour] == 2:
                    deg2.append(min_deg_neighbour)
                elif cgraph.degree[min_deg_neighbour] == 1:
                    deg1.append(min_deg_neighbour)

            deg2.remove(vertex)

    return [cgraph, iv]


def computeGamma(graph, cgraph, iv):
    density = {}
    quality = {}

    max_den = 0
    max_qual = 0
    for vertex in cgraph.nodes:
        density[vertex] = cgraph.degree[vertex]
        quality[vertex] = len(iv[vertex])

        if density[vertex] == 0 and quality[vertex] > 1:
            density[vertex] = sum([graph.degree[k] for k in nx.neighbors((graph, vertex))])
            nn = len(nx.neighbors(graph, vertex))

            density[vertex] = density[vertex] / nn

        max_den = max(max_den, density[vertex])
        max_qual = max(max_qual, quality[vertex])

    gamma = {}
    for vertex in cgraph.nodes:
        density[vertex] = density[vertex] / max_den
        quality[vertex] = quality[vertex] / max_qual
        gamma[vertex] = density[vertex] * quality[vertex]

    return gamma


def findKneePoint(gamma):
    gammaList = list(gamma.values())
    gammaList.sort(reverse=True)
    print("Gamma list = " + str(gammaList))
    max_hi = 0
    argmax_hi = -1
    for k in range(0, len(gammaList) - 3):
        hi = (gammaList[k] - gammaList[k + 1]) - (gammaList[k + 1] -
                                                  gammaList[k + 2])
        hi = abs(hi)

        if hi >= max_hi:
            max_hi = hi
            argmax_hi = k
            print(argmax_hi)

    # print("Gamme = " + str(gammaList[argmax_hi]))
    return gammaList[argmax_hi]


def determineSeeds(graph, cgraph, iv):
    gamma = computeGamma(graph, cgraph, iv)
    gammaKp = findKneePoint(gamma)

    seeds = set({})
    # print("Max gamma = " + str(max(gamma.values())))
    for vertex in cgraph.nodes:
        # print(str(vertex) + " " + str(gamma[vertex]))
        if gamma[vertex] >= gammaKp:
            seeds.add(vertex)

    remSet = set({})
    for vertexi in seeds:
        for vertexj in seeds:
            if cgraph.has_edge(vertexi, vertexj) and vertexi not in remSet and vertexj not in remSet:
                remSet.add(vertexj)

    seeds = seeds - remSet

    return seeds


def initCV(cgraph, seeds):
    CV = set({})

    for seed in seeds:
        for neighbour in nx.neighbors(cgraph, seed):
            CV.add(neighbour)

    return CV


def addToCommunity(cgraph, C, CV, vertex, seed):
    C[seed].add(vertex)
    CV.remove(vertex)

    for neighbour in nx.neighbors(cgraph, vertex):
        if neighbour not in C[seed]:
            CV.add(neighbour)


def similarity(cgraph, C, vertex, seed):
    sim = 0

    neighbours = set(nx.neighbors(cgraph, vertex))
    neighbours_in_c = neighbours.intersection(C[seed])

    for neighbour in neighbours_in_c:
        sim = sim + cgraph.edges[vertex, neighbour]["weight"]
        neighbours_of_neighbour = set(nx.neighbors(cgraph, neighbour))
        common_neighbours = neighbours.intersection(neighbours_of_neighbour)

        for common_neighbour in common_neighbours:
            edge_sum = 0
            for v in nx.neighbors(cgraph, common_neighbour):
                edge_sum = edge_sum + cgraph.edges[common_neighbour, v]["weight"]
            sim = sim + 1 / edge_sum

    return sim


def expandSeeds(cgraph, seeds):
    C = {}
    UL = set(cgraph.nodes)
    UL = UL - seeds

    for seed in seeds:
        C[seed] = {seed}

    CV = initCV(cgraph, seeds)
    while len(UL) != 0:
        TC = {seed: set({}) for seed in seeds}

        for vertex in CV:
            if vertex in UL:
                neighbours = set(nx.neighbors(cgraph, vertex))
                subset_com = [k for k in seeds if neighbours.issubset(C[k])]

                if len(subset_com) == 0:
                    max_sim = 0
                    max_sim_arg = -1
                    for seed in seeds:
                        sim = similarity(cgraph, C, vertex, seed)
                        if sim > max_sim:
                            max_sim = sim
                            max_sim_arg = seed
                    TC[max_sim_arg].add(vertex)

                elif len(subset_com) == 1:
                    TC[subset_com[0]].add(vertex)

                else:
                    print("Error ! Subset Community length more than one")
                    print(neighbours)

                    for seed1 in subset_com:
                        print(C[seed1])

                    print("----------")
                UL.remove(vertex)

        for seed in seeds:
            for vertex in TC[seed]:
                addToCommunity(cgraph, C, CV, vertex, seed)

    return C


def modularity(graph, C, seeds):
    Q = 0
    m = graph.number_of_edges()

    for seed in seeds:
        for vi in C[seed]:
            for vj in C[seed]:
                if graph.has_edge(vi, vj):
                    A = 1
                else:
                    A = 0
                di = graph.degree[vi]
                dj = graph.degree[vj]

                d = di * dj
                Q = Q + (A - d / (2 * m))

    Q = Q / (2 * m)
    return Q


ui()
