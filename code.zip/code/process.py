import networkx as nx


def processDataSets():
    # process PGP.net
    graph = nx.read_pajek("PGP.net")
    graph = nx.Graph(graph)
    nx.write_weighted_edgelist(graph, "PGP.edgelist")
    print("PGP " + str(len(graph.nodes)) + " " + str(graph.number_of_edges()))
    graph = nx.read_weighted_edgelist("email.txt")
    graph = nx.Graph(graph)
    nx.write_weighted_edgelist(graph, "email.edgelist")


processDataSets()
