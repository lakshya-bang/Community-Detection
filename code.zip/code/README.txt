Running:

install networkx using the below commnad:
	pip install networkx

run main.py as follows:
	python main.py